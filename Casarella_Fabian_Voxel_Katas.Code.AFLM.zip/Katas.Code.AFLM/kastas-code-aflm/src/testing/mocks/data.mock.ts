export class DataMock {
    getResultEntriesMock() {
        return {
            count: 2,
            entries: [
                {
                    API: 'API1',
                    Description: 'Description1',
                    Auth: 'Auth1',
                    HTTPS: false,
                    Cors: '',
                    Link: '',
                    Category: '',
                },
                {
                    API: 'API2',
                    Description: 'Description2',
                    Auth: 'Auth2',
                    HTTPS: false,
                    Cors: '',
                    Link: '',
                    Category: '',
                }
            ]
          };
    }
}
