import { Entrie } from './entrie';

export class ResultEntries {
    count: number;
    entries: Entrie[];
    constructor() {
      this.count = 0;
      this.entries = [];
    }
  }
