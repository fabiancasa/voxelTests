export class Navigation {
    navAnimals: boolean;
    navBooks: boolean;
    navMusic: boolean;
    navHealth: boolean;

    constructor() {
        this.navAnimals = false;
        this.navBooks = false;
        this.navMusic = false;
        this.navHealth = false;
    }
  }
