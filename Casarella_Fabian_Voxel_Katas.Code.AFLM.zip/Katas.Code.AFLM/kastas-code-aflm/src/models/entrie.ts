export class Entrie {
    API: string;
    Description: string;
    Auth: string;
    HTTPS: boolean;
    Cors: string;
    Link: string;
    Category: string;

    constructor() {
      this.API = '';
      this.Description = '';
      this.Auth = '';
      this.HTTPS = false;
      this.Cors = '';
      this.Link = '';
      this.Category = '';
    }
}
