import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { ResultEntries } from 'src/models/resultEntries';
import { environment } from 'src/environments/environment';


@Injectable({
  providedIn: 'root'
})
export class AflmService {
  private url = environment.uriApi;

  constructor(private http: HttpClient) { }

  getEntries(section: string): Observable<ResultEntries> {
    return this.http.get<ResultEntries>(`${ this.url }${section}`);
  }
}


