import { Injectable } from '@angular/core';
import { Navigation } from '../models/navigation';
import { Router } from '@angular/router';
import { stringify } from '@angular/core/src/util';

@Injectable({
  providedIn: 'root'
})
export class NavigationService {

  constructor(private router: Router) { }

  getNavigationStorage(): Navigation {
    return JSON.parse(localStorage.getItem('navigation'));
  }

  setNavigationStorage(nav: Navigation) {
    localStorage.setItem('navigation', JSON.stringify(nav));
  }

  executetNavigationRoute(section: string) {
    let pathRoute = ['/error'];
    let nav: Navigation;
    nav = this.getNavigationStorage();
    if (nav === null) {
      nav = new Navigation();
    }

    switch (section) {
      case 'animals': {
        pathRoute = ['/card', section];
        nav.navAnimals = true;
        nav.navBooks = false;
        nav.navMusic = false;
        nav.navHealth = false;
        this.setNavigationStorage(nav);
        break;
       }
       case 'books': {
        if (nav.navAnimals) {
          pathRoute = ['/card', section];
          nav.navBooks = true;
          nav.navMusic = false;
          nav.navHealth = false;
          this.setNavigationStorage(nav);
        }
        break;
       }
       case 'music': {
        if (nav.navAnimals && nav.navBooks) {
          pathRoute = ['/card', section];
          nav.navMusic = true;
          this.setNavigationStorage(nav);
        }
        break;
       }
       case 'health': {
        if (nav.navAnimals && nav.navBooks && nav.navMusic) {
          pathRoute = ['/card', section];
          nav.navHealth = true;
          this.setNavigationStorage(nav);
        }
        break;
       }
    }

    this.router.navigate(pathRoute);
  }
}
