import { Component, OnInit, Input } from '@angular/core';
import { Entrie } from 'src/models/entrie';

@Component({
  selector: 'app-card-grid',
  templateUrl: './card-grid.component.html',
  styleUrls: ['./card-grid.component.scss']
})
export class CardGridComponent implements OnInit {
  @Input() entries: Entrie[] = [];
  selectedEntrie: Entrie;

  constructor() { }

  ngOnInit() {
  }
  onSelect(entrie: Entrie): void {
    this.selectedEntrie = entrie;
  }

}
