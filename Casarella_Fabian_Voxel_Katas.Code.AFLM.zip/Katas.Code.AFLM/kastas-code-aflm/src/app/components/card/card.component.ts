import { Component, OnInit } from '@angular/core';
import { AflmService } from 'src/services/aflm.service';
import { ActivatedRoute, Router } from '@angular/router';
import { Entrie } from 'src/models/entrie';
import { ResultEntries } from 'src/models/resultEntries';

@Component({
  selector: 'app-card',
  templateUrl: './card.component.html',
  styleUrls: ['./card.component.scss']
})
export class CardComponent implements OnInit {

  public entries: Entrie[];
  public entrie: Entrie;
  public title: string;

  constructor(private activatedRoute: ActivatedRoute,
    private aflmService: AflmService,
    private router: Router) {
      this.entries = [];
      this.entrie = new Entrie();
  }

  ngOnInit() {
    this.getEntries();
  }

  getEntries() {
    this.activatedRoute.params.subscribe(params => {
      this.setTitle(params['section']);

      this.aflmService.getEntries(params['section']).subscribe(
        (res: ResultEntries) => {
          this.entries.push( ...res.entries);
        });

        console.log('fabian1');
    });
  }

  goBack() {
    this.router.navigate(['/home']);
  }

  setTitle(section: string) {
    switch (section) {
      case 'animals': {
        this.title = 'ANIMALES';
        break;
       }
       case 'books': {
        this.title = 'LIBROS';
        break;
       }
       case 'music': {
        this.title = 'MÚSICA';
        break;
       }
       case 'health': {
        this.title = 'SALUD';
        break;
       }
    }
  }
}
