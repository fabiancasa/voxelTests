import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CardComponent } from './card.component';
import { ActivatedRouteStub } from 'src/testing/activated-route-stub';
import { ActivatedRoute, Router } from '@angular/router';
import { AflmService } from 'src/services/aflm.service';
import { DataMock } from 'src/testing/mocks/data.mock';
import { CardGridComponent } from '../card-grid/card-grid.component';
import { CardGridDetailComponent } from '../card-grid-detail/card-grid-detail.component';

describe('CardComponent', () => {
  let component: CardComponent;
  let fixture: ComponentFixture<CardComponent>;
  let activatedRoute: ActivatedRouteStub;
  let aflmServiceSpy: jasmine.SpyObj<AflmService>;
  const dataMock = new DataMock();

  beforeEach(async(() => {

    activatedRoute = new ActivatedRouteStub();
    activatedRoute.testParams = { section: 'animals' };

    const spyAflmService = jasmine.createSpyObj('AflmService', ['getEntries']);
    const mockRouter = {
      navigate: jasmine.createSpy('navigation')
    };

    const MOCKED_ENTRIES = dataMock.getResultEntriesMock();

    TestBed.configureTestingModule({
      declarations: [ CardComponent, CardGridComponent, CardGridDetailComponent ],
      providers: [
        { provide: ActivatedRoute, useValue: activatedRoute },
        { provide: AflmService, useValue: spyAflmService },
        { provide: Router, useValue: mockRouter }
      ]
    })
    .compileComponents();

    aflmServiceSpy = TestBed.get(AflmService);
    aflmServiceSpy.getEntries.and.returnValue(MOCKED_ENTRIES);
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
