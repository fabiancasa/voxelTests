import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { HomeComponent } from './home.component';
import { NavigationService } from 'src/services/navigation.service';

describe('HomeComponent', () => {
  let fixture: ComponentFixture<HomeComponent>;

  beforeEach(async(() => {
    const spyNavService = jasmine.createSpyObj('NavigationService', ['executetNavigationRoute']);

    TestBed.configureTestingModule({
      declarations: [ HomeComponent ],
      providers: [
        { provide: NavigationService, useValue: spyNavService }
      ]
    })
    .compileComponents();
  }));


  it('should create the home component', () => {
    fixture = TestBed.createComponent(HomeComponent);
    const app = fixture.debugElement.componentInstance;
    expect(app).toBeTruthy();
  });

  it('should render title in a h3 tag', () => {
    fixture = TestBed.createComponent(HomeComponent);
    fixture.detectChanges();
    const compiled = fixture.debugElement.nativeElement;
    expect(compiled.querySelector('h3').textContent).toContain('Bienvenido al nuevo repositorio de la');
  });
});
