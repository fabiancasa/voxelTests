import { Component, OnInit, Input } from '@angular/core';
import { Entrie } from 'src/models/entrie';

@Component({
  selector: 'app-card-grid-detail',
  templateUrl: './card-grid-detail.component.html',
  styleUrls: ['./card-grid-detail.component.scss']
})
export class CardGridDetailComponent implements OnInit {
  @Input() entrie: Entrie = null;

  constructor() { }

  ngOnInit() {
  }

  onNavigate(link: string) {
    window.open(link, '_blank');
}

}
