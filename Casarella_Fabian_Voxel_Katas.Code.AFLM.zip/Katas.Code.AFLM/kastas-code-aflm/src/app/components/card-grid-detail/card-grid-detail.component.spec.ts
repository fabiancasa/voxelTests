import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CardGridDetailComponent } from './card-grid-detail.component';

describe('CardGridDetailComponent', () => {
  let component: CardGridDetailComponent;
  let fixture: ComponentFixture<CardGridDetailComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CardGridDetailComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CardGridDetailComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
