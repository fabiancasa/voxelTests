export const environment = {
  production: true,
  uriApi: 'https://api.publicapis.org/entries?category='
};
