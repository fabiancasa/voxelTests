﻿using System.Threading.Tasks;
using Voxel.AnonymousPollEntities.DTOs;

namespace Voxel.AnonymousPollBusiness.Contract
{
    public interface IPollService
    {
        Task<SearchDataResponse> ExecuteAsync(SearchDataRequest request);
    }
}
