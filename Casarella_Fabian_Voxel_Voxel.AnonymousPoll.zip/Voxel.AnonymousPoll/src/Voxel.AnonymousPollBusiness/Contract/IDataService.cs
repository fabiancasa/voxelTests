﻿using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using Voxel.AnonymousPollEntities.DTOs;

namespace Voxel.AnonymousPollBusiness.Contract
{
    public interface IDataService
    {
        Task<BulkDataResponse> BulkDataAsync(IFormFile file);
    }
}
