﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using AutoMapper;
using Voxel.AnonymousPollBusiness.Contract;
using Voxel.AnonymousPollBusiness.Services;
using Voxel.AnonymousPoll.Library.Parser;
using Voxel.AnonymousPollEntities.DTOs;
using Voxel.AnonymousPollEntities.Entities;
using Voxel.AnonymousPollBusiness.Mappings;

namespace Voxel.AnonymousPollBusiness.DI
{
    public static class DefaultDI
    {
        public static IServiceCollection AddBusinessServices(this IServiceCollection services, IConfiguration configuration)
        {
            //services.AddAutoMapper(typeof(DefaultDI));

            services.AddSingleton<IMapper>(MappingProfile.GetMapper());
            services.AddScoped<IDataService, DataService>();
            services.AddScoped<IPollService, PollService>();
            services.AddScoped<IParserData<BulkDataRequest>, ParserData<BulkDataRequest>>();
            services.AddScoped<IParserData<SearchData>, ParserData<SearchData>>();


            return services;
        }
    }
}
