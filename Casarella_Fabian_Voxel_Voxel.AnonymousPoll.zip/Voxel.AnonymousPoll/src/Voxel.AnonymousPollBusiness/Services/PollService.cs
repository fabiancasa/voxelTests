﻿using AutoMapper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Voxel.AnonymousPoll.Library.Parser;
using Voxel.AnonymousPoll.Library.Tools;
using Voxel.AnonymousPollBusiness.Contract;
using Voxel.AnonymousPollEntities.DTOs;
using Voxel.AnonymousPollEntities.Entities;
using Voxel.AnonymousPollSqlDataAccess.Contract;

namespace Voxel.AnonymousPollBusiness.Services
{
    public class PollService : IPollService
    {
        private readonly IStudentRepository _studentRepository;
        private readonly IMapper _mapper;
        private readonly IParserData<SearchData> _parserData;

        public PollService(IStudentRepository studentRepository,
            IMapper mapper,
            IParserData<SearchData> parserData)
        {
            _studentRepository = studentRepository;
            _mapper = mapper;
            _parserData = parserData;
        }

        public async Task<SearchDataResponse> ExecuteAsync(SearchDataRequest request)
        {
            // Get the data to match with DB
            IList<SearchData> list = _parserData.ExecuteByStringList(request.Cases);

            // Get the data matched
            IList<Student> matched = await _studentRepository.MatchAsync(list);

            List<string> result = new List<string>();
            int i = 1;
            foreach (var t in list)
            {
                string caseResult = string.Join(",", matched.Where(x => x.Gender == t.Gender
                                                        && x.Age == t.Age
                                                        && x.Education == t.Education
                                                        && x.AcademicYear == t.AcademicYear)
                                                            .Select(x => x.Name)
                                                            .OrderBy(x => x));
                if (string.IsNullOrEmpty(caseResult))
                {
                    result.Add($"Case #{ i }: NONE");
                }
                else
                {
                    result.Add($"Case #{ i }: { caseResult }");
                }
                i++;
            }

            return new SearchDataResponse()
            {
                Result = result
            };
        }
    }
}
