﻿using AutoMapper;
using Microsoft.AspNetCore.Http;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Voxel.AnonymousPoll.Library.Parser;
using Voxel.AnonymousPollBusiness.Contract;
using Voxel.AnonymousPollEntities.DTOs;
using Voxel.AnonymousPollEntities.Entities;
using Voxel.AnonymousPollSqlDataAccess.Contract;

namespace Voxel.AnonymousPollBusiness.Services
{
    public class DataService : IDataService
    {
        private readonly IStudentRepository _studentRepository;
        private readonly IMapper _mapper;
        private readonly IParserData<BulkDataRequest> _parserData;

        public DataService(IStudentRepository studentRepository,
            IMapper mapper,
            IParserData<BulkDataRequest> parserData)
        {
            _studentRepository = studentRepository;
            _mapper = mapper;
            _parserData = parserData;
        }

        public async Task<BulkDataResponse> BulkDataAsync(IFormFile file)
        {            
            IList<string> result = new List<string>();

            using (StreamReader reader = new StreamReader(file.OpenReadStream()))
            {
                // Get the data from CSV file
                IList<BulkDataRequest> records = _parserData.Execute(reader);

                // Map the CSV data with the entity db model
                IList<Student> studentList = _mapper.Map<IList<Student>>(records.ToList());

                int iRecord = 1;
                int iRecordInserted = 0;

                // Validate if exist the student info and insert into DB
                foreach (Student entity in studentList)
                {
                    Student student = await _studentRepository.SearchStudentAsync(entity);

                    if (student != null)
                    {
                        result.Add($"The record { iRecord } exist in DB");
                    }
                    else
                    {
                        student = await _studentRepository.AddAsync(entity);
                        iRecordInserted++;
                    }

                    iRecord++;
                }

                result.Add($"{ iRecordInserted } records were inserted in DB");
            }

            return new BulkDataResponse()
            {
                Result = result
            };
        }
    }
}
