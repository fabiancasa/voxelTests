﻿using AutoMapper;
using Voxel.AnonymousPollEntities.DTOs;
using Voxel.AnonymousPollEntities.Entities;

namespace Voxel.AnonymousPollBusiness.Mappings
{
    public static class MappingProfile
    {

        /// <summary>
        /// Gets the auto mapping configuration.
        /// </summary>
        public static IMapper GetMapper()
        {
            return new MapperConfiguration(cfg =>
            {
                cfg.CreateMap<Student, BulkDataRequest>().ReverseMap();

            }).CreateMapper();
        }
    }
}
