﻿using System.Collections.Generic;
using System.IO;
using System.Threading.Tasks;

namespace Voxel.AnonymousPoll.Library.Parser
{
    public interface IParserData<TData>
    {
        IList<TData> ExecuteByStringList(IList<string> data);

        IList<TData> Execute(TextReader data);
    }
}
