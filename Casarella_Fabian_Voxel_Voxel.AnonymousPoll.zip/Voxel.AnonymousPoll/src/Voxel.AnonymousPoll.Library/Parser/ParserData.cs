﻿using CsvHelper;
using Microsoft.Extensions.Options;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Voxel.AnonymousPollEntities.Config;
using Voxel.AnonymousPollEntities.Exceptions;

namespace Voxel.AnonymousPoll.Library.Parser
{
    public class ParserData<TData> : IParserData<TData>
    {
        private readonly ParserConfig _parserConfig;

        public ParserData(IOptions<ParserConfig> parserConfig)
        {
            _parserConfig = parserConfig.Value;
        }

        public IList<TData> ExecuteByStringList(IList<string> data)
        {
            var reader = new StringReader(string.Join(_parserConfig.NewLine, data));

            return Execute(reader);
        }

        public IList<TData> Execute(TextReader data)
        {
            IList<TData> result = null;
            try
            {
                using (CsvReader csv = new CsvReader(data))
                {
                    csv.Configuration.HasHeaderRecord = _parserConfig.HasHeaderRecord;
                    csv.Configuration.Delimiter = _parserConfig.Delimiter;

                    result = csv.GetRecords<TData>().ToList();
                }
            }
            catch (Exception ex)
            {
                throw new ServiceException("DataParse", $"The format file is not correct. Error: { ex.Message }");
            }

            return result;
        }
    }
}
