﻿namespace Voxel.AnonymousPoll.Library.Tools
{
    public static class JsonSerializerObject
    {
        public static string ToJson(this object obj)
        {
            return Newtonsoft.Json.JsonConvert.SerializeObject(obj);
        }
    }
}
