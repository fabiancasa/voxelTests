﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Voxel.AnonymousPoll.Library.Tools
{
    public static class IntegerExtension
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="int"></param>
        public static int? ToInt(this string value)
        {
            int.TryParse(value, out int parseValue);

            return parseValue;
        }
    }
}
