﻿using Microsoft.EntityFrameworkCore;
using Voxel.AnonymousPollEntities.Entities;

namespace Voxel.AnonymousPollSqlDataAccess
{
    public class VoxelDBContext : DbContext
    {
        public VoxelDBContext(DbContextOptions options)
            : base(options)
        {
        }

        public DbSet<Student> Students { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder.Entity<Student>();
        }
    }
}
