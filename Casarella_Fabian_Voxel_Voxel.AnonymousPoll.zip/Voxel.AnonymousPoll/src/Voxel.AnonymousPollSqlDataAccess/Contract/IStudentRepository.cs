﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using Voxel.AnonymousPollEntities.Entities;

namespace Voxel.AnonymousPollSqlDataAccess.Contract
{
    public interface IStudentRepository
    {
        Task<Student> SearchStudentAsync(Student entity);

        Task<Student> AddAsync(Student entity);

        Task<IList<Student>> MatchAsync(IList<SearchData> dataList);
    }
}
