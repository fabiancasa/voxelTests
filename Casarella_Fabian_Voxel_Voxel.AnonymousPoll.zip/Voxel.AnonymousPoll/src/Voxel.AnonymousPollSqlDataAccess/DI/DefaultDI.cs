﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Voxel.AnonymousPollSqlDataAccess.Contract;
using Voxel.AnonymousPollSqlDataAccess.Repositories;

namespace Voxel.AnonymousPollSqlDataAccess.DI
{
    public static class DefaultDI
    {
        public static IServiceCollection AddDataAccessServices(this IServiceCollection services, IConfiguration configuration)
        {

            services.AddScoped<IStudentRepository, StudentRepository>();

            return services;
        }
    }
}
