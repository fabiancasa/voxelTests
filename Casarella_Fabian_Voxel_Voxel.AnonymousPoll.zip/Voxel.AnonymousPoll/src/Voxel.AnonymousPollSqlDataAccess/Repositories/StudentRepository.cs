﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Voxel.AnonymousPollEntities.Entities;
using Voxel.AnonymousPollSqlDataAccess.Contract;

namespace Voxel.AnonymousPollSqlDataAccess.Repositories
{
    public class StudentRepository : IStudentRepository
    {
        private readonly VoxelDBContext _context;

        public StudentRepository(VoxelDBContext context)
        {
            _context = context;
        }

        public async Task<Student> AddAsync(Student entity)
        {
            entity.CreatedDate = DateTime.Now;
            await _context.Students.AddAsync(entity);
            await _context.SaveChangesAsync();

            return entity;
        }

        public async Task<IList<Student>> MatchAsync(IList<SearchData> dataList)
        {
            var resultMatch = from std in _context.Students
                join data in dataList
                    on
                    new { std.Gender, std.Age, std.Education, std.AcademicYear }
                    equals new { data.Gender, data.Age, data.Education, data.AcademicYear }
                    into match
                    from m in match.DefaultIfEmpty()
                    where m != null
                    select std;

            return await resultMatch.ToListAsync();
        }

        public async Task<Student> SearchStudentAsync(Student entity)
        {
            return await QueryStudent(entity).FirstOrDefaultAsync();
        }

        private IQueryable<Student> QueryStudent(Student student)
        {
            var query = _context.Students.Where(x => x.Gender == student.Gender);

            if (!string.IsNullOrEmpty(student.Name))
            {
                query = query.Where(x => x.Name == student.Name);
            }

            query = query.Where(x => x.Age == student.Age);
            query = query.Where(x => x.Education == student.Education);
            query = query.Where(x => x.AcademicYear == student.AcademicYear);

            return query;
        }
    }
}
