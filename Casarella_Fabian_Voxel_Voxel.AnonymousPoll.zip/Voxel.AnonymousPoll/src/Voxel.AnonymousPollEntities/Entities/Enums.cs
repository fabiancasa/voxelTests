﻿namespace Voxel.AnonymousPollEntities.Entities
{
    public enum GenderEnum
    {
        M = 1,
        F = 2
    }
}
