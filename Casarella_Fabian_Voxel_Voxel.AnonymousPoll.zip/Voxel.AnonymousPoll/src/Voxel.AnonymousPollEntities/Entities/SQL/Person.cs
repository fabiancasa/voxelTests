﻿using System.ComponentModel.DataAnnotations;

namespace Voxel.AnonymousPollEntities.Entities
{
    public abstract class Person: BaseEntity
    {
        [Required]
        [MaxLength(400)]
        public string Name { get; set; }

        [Required]
        [MaxLength(1)]
        public GenderEnum Gender { get; set; }

        [Required]
        public int Age { get; set; }
    }
}
