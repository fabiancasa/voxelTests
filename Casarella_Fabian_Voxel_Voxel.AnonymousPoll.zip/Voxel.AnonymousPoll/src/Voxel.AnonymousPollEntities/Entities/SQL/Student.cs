﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace Voxel.AnonymousPollEntities.Entities
{
    public class Student : Person
    {
        [Key]
        public int Id { get; set; }

        [Required]
        [MaxLength(200)]
        public string Education { get; set; }

        [Required]
        public int AcademicYear { get; set; }
    }
}
