﻿namespace Voxel.AnonymousPollEntities.Entities
{
    public class SearchData
    {
        public GenderEnum Gender { get; set; }
        public int Age { get; set; }
        public string Education { get; set; }
        public int AcademicYear { get; set; }
    }
}
