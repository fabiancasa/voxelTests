﻿using System.Collections.Generic;

namespace Voxel.AnonymousPollEntities.Exceptions
{
    public class ServiceException : System.Exception
    {
        public IDictionary<string, IList<string>> Errors { get; private set; }

        public ServiceException()
        {
        }

        public ServiceException(string message) : base(message)
        {
        }

        public ServiceException(string key, string errorMessage)
        {
            AddError(key, errorMessage);
        }

        public ServiceException(string message, string key, string errorMessage) : base(message)
        {
            AddError(key, errorMessage);
        }

        private void AddError(string key, string errorMessage)
        {
            if (Errors == null)
            {
                Errors = new Dictionary<string, IList<string>>();
            }
            if (Errors.ContainsKey(key))
            {
                Errors[key].Add(errorMessage);
            }
            else
            {
                Errors.Add(key, new List<string> { errorMessage });
            }
        }
    }
}
