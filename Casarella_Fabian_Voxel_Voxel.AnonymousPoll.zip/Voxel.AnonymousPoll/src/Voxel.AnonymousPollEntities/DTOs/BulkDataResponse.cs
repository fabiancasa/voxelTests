﻿using System.Collections.Generic;

namespace Voxel.AnonymousPollEntities.DTOs
{
    public class BulkDataResponse
    {
        public IList<string> Result { get; set; }
    }
}
