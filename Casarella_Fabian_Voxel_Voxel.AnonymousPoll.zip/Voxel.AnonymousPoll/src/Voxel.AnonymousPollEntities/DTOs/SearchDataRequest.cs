﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace Voxel.AnonymousPollEntities.DTOs
{
    public class SearchDataRequest
    {
        [Required (ErrorMessage = "The cases counter is required.")]
        public int? TCases { get; set; }

        [Required]
        public IList<string> Cases { get; set; }
    }
}
