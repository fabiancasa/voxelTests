﻿using Microsoft.AspNetCore.Http;
using Voxel.AnonymousPollEntities.Entities;

namespace Voxel.AnonymousPollEntities.DTOs
{
    public class BulkDataRequest
    {
        public string Name { get; set; }
        public GenderEnum Gender { get; set; }
        public int Age { get; set; }
        public string Education { get; set; }
        public int AcademicYear { get; set; }

    }
}
