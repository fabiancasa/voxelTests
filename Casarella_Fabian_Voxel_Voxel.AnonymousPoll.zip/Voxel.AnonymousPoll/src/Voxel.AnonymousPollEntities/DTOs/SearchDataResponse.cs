﻿using System.Collections.Generic;

namespace Voxel.AnonymousPollEntities.DTOs
{
    public class SearchDataResponse
    {
        public IList<string> Result { get; set; }
    }
}
