﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Voxel.AnonymousPollEntities.Config
{
    public class ParserConfig
    {
        public string Delimiter { get; set; }

        public bool HasHeaderRecord { get; set; }

        public string NewLine { get; set; }
    }
}
