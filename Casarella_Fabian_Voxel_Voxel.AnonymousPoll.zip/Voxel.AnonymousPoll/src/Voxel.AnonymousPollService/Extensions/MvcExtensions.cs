﻿using Microsoft.AspNetCore.Mvc.Infrastructure;
using Microsoft.AspNetCore.Mvc.ModelBinding;
using System.Collections.Generic;

namespace Voxel.AnonymousPollService.Extensions
{
    /// <summary>
    /// Extension methods for mvc
    /// </summary>
    public static class MvcExtensions
    {
        /// <summary>
        /// Extension method for adding model errros.
        /// </summary>
        /// <param name="value">The model state dictionary.</param>
        /// <param name="errors">The errors to be added.</param>
        public static void AddModelErrors(this ModelStateDictionary value, IDictionary<string, IList<string>> errors)
        {
            AddModelErrors(value, errors, null);
        }

        /// <summary>
        /// Extension method for adding model errros.
        /// </summary>
        /// <param name="value">The model state dictionary.</param>
        /// <param name="errors">The errors to be added.</param>
        /// <param name="prefix">If a prfix is required. Such as patient.patiendId</param>
        public static void AddModelErrors(this ModelStateDictionary value, IDictionary<string, IList<string>> errors, string prefix = "")
        {
            if (errors?.Count > 0)
            {
                foreach (var pair in errors)
                {
                    var key = prefix + pair.Key;
                    foreach (var val in pair.Value)
                    {
                        value.AddModelError(key, val);
                    }
                }
            }
        }

        ///// <summary>
        ///// Gets the Id from the ActionContext if present on the path
        ///// </summary>
        ///// <param name="value">The interface for ActionContext</param>
        ///// <returns>The path id</returns>
        //public static long? GetId(this IActionContextAccessor value)
        //{
        //    var id = value?.ActionContext?.RouteData?.Values["id"];
        //    if (id != null)
        //    {
        //        if (long.TryParse(id.ToString(), out var result))
        //        {
        //            return result;
        //        }
        //    }
        //    return null;
        //}
    }
}
