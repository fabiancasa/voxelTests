﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;

namespace Voxel.AnonymousPollService.ActionFilter
{
    /// <summary>
    /// Validation to check for model state errors.
    /// </summary>
    public class ValidateModelStateAttribute : ActionFilterAttribute
    {
        /// <summary>
        /// Creates and initializes an instance of type <see href="ValidateModelStateAttribute"/>
        /// </summary>
        public ValidateModelStateAttribute()
        {
        }

        /// <summary>
        /// Runs before controller method to validation model state.
        /// </summary>
        /// <param name="context"></param>
        public override void OnActionExecuting(ActionExecutingContext context)
        {
            var modelState = context.ModelState;

            if (!modelState.IsValid)
            {
                context.Result = new BadRequestObjectResult(context.ModelState);
            }

            base.OnActionExecuting(context);
        }
    }
}
