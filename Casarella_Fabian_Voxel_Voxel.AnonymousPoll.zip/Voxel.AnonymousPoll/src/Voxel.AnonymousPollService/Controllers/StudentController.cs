﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;
using Voxel.AnonymousPollBusiness.Contract;
using Voxel.AnonymousPollEntities.DTOs;
using Voxel.AnonymousPollEntities.Exceptions;
using Voxel.AnonymousPollService.Extensions;

namespace Voxel.AnonymousPollService.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class StudentController : ControllerBase
    {
        private readonly IDataService _dataService;
        private readonly IPollService _anonymousPollService;

        public StudentController(IDataService dataService,
            IPollService anonymousPollService)
        {
            _dataService = dataService;
            _anonymousPollService = anonymousPollService;
        }

        [HttpPost("bulk")]
        public async Task<ActionResult<BulkDataResponse>> BulkDataAsync(IFormFile file)
        {
            try
            {
                var response = await _dataService.BulkDataAsync(file);
                return Ok(response);
            }
            catch (ServiceException ex)
            {
                ModelState.AddModelErrors(ex.Errors);
                return BadRequest(ModelState);
            }
        }

        [HttpPost("poll/match")]
        public async Task<ActionResult<SearchDataResponse>> MatchDataAsync([FromBody] SearchDataRequest request)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            try
            {
                var response = await _anonymousPollService.ExecuteAsync(request);
                return Ok(response);
            }
            catch (ServiceException ex)
            {
                ModelState.AddModelErrors(ex.Errors);
                return BadRequest(ModelState);
            }
        }

        [HttpGet("check")]
        public ActionResult<string> Check()
        {
            return Ok("OK");
        }
    }
}
