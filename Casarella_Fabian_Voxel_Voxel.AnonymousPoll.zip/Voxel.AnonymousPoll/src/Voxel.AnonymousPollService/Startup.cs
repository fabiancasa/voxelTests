﻿using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json.Serialization;
using Serilog;
using Serilog.Core;
using System.IO;
using System.Net.Http;
using Voxel.AnonymousPollBusiness.Contract;
using Voxel.AnonymousPollBusiness.DI;
using Voxel.AnonymousPollBusiness.Services;
using Voxel.AnonymousPollEntities.Config;
using Voxel.AnonymousPollService.ActionFilter;
using Voxel.AnonymousPollService.Config;
using Voxel.AnonymousPollSqlDataAccess;
using Voxel.AnonymousPollSqlDataAccess.Contract;
using Voxel.AnonymousPollSqlDataAccess.DI;
using Voxel.AnonymousPollSqlDataAccess.Repositories;

namespace Voxel.AnonymousPollService
{
    public class Startup
    {
        /// <summary>
        /// Gets the service configuration provider.
        /// </summary>
        /// <returns>An instance of <see cref="IConfigurationRoot"/> interface.</returns>
        public IConfigurationRoot Configuration { get; }

        private readonly ILoggerFactory _loggerFactory;

        private readonly IHostingEnvironment _currentEnvironment;

        public Startup(IHostingEnvironment env, ILoggerFactory loggerFactory)
        {
            _loggerFactory = loggerFactory;
            _currentEnvironment = env;

            var builder = new ConfigurationBuilder()
                .SetBasePath(env.ContentRootPath)
                .AddJsonFile("appsettings.json", optional: true, reloadOnChange: true)
                .AddJsonFile($"appsettings.{env.EnvironmentName}.json", optional: true, reloadOnChange: true)
                .AddEnvironmentVariables();

            Configuration = builder.Build();
        }

        public void ConfigureServices(IServiceCollection services)
        {
            var appSettings = new AppSettings();
            Configuration.GetSection("AppSettings").Bind(appSettings);

            services.Configure<ParserConfig>(Configuration.GetSection("ParserConfig"));

            services.AddSingleton(appSettings);

            AddEntityFramework(services);

            services.AddMvcCore(opt =>
            {
                if (appSettings.GlobalExceptionFilterEnabled)
                {
                    opt.Filters.Add(new GlobalExceptionFilter(_loggerFactory));
                }
                opt.Filters.Add(new ValidateModelStateAttribute()); // Add global model state validation
            })
            .AddDataAnnotations()
            .AddJsonFormatters(j => j.ContractResolver = new CamelCasePropertyNamesContractResolver())
            .AddApiExplorer();

            var level = new LoggingLevelSwitch
            {
                MinimumLevel = appSettings.LoggingLevel
            };

            Log.Logger = new LoggerConfiguration()
                .MinimumLevel.ControlledBy(level)
                .Enrich.FromLogContext()
                .Enrich.WithProperty("Environment", _currentEnvironment.EnvironmentName)
                .WriteTo.Console(outputTemplate: "{Timestamp:yyyy-MM-dd HH:mm:ss} {Environment} {SourceContext} {Level} {Message}{NewLine}{Exception}")
                .CreateLogger();


            services.AddMvc().SetCompatibilityVersion(CompatibilityVersion.Version_2_2);

            services.AddMvc();

            services.AddBusinessServices(Configuration);
            services.AddDataAccessServices(Configuration);

            AddExternalServices(services);
        }

        /// <summary>
        /// Configures external services.
        /// </summary>
        /// <param name="services">The collection of services to add.</param>
        public virtual void AddExternalServices(IServiceCollection services)
        {
            services.AddTransient<HttpClient, HttpClient>();
        }

        public void Configure(IApplicationBuilder app,
            IHostingEnvironment env,
            ILoggerFactory loggerFactory,
            VoxelDBContext context)
        {
            loggerFactory.AddSerilog();
            //loggerFactory.AddDebug();
            //loggerFactory.AddConsole(Configuration.GetSection("Logging"));

            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }

            app.UseCors(cfg => cfg.AllowAnyOrigin());

            app.Use(async (httpContext, next) =>
            {
                await next();

                if (httpContext.Response.StatusCode == 404 &&
                    httpContext.Request.Path.HasValue &&
                    !Path.HasExtension(httpContext.Request.Path.Value))
                {
                    httpContext.Request.Path = "/";
                    await next();
                }
            });

            app.UseDefaultFiles();

            app.UseStaticFiles();

            app.UseMvc();

            RunMigration(context);
        }

        public virtual void RunMigration(VoxelDBContext context)
        {
            context.Database.Migrate();
        }

        /// <summary>
        /// Configures EntityFrameworkCore.
        /// </summary>
        /// <param name="services">The collection of services to add.</param>
        public virtual void AddEntityFramework(IServiceCollection services)
        {
            services.AddDbContext<VoxelDBContext>(cfg =>
            {
                cfg.UseSqlServer(Configuration.GetConnectionString("DBConnectionString"));
            });
        }
    }
}