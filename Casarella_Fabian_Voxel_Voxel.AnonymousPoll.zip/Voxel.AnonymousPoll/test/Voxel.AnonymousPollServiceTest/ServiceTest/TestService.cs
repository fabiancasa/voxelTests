﻿using Microsoft.Data.Sqlite;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Moq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Voxel.AnonymousPollSqlDataAccess;
using Xunit;
using Voxel.AnonymousPollBusiness.Services;
using Voxel.AnonymousPollBusiness.Contract;
using Voxel.AnonymousPollSqlDataAccess.Contract;
using AutoMapper;
using Voxel.AnonymousPoll.Library.Parser;
using Voxel.AnonymousPollEntities.Entities;
using Voxel.AnonymousPollSqlDataAccess.Repositories;
using Voxel.AnonymousPollEntities.DTOs;
using Voxel.AnonymousPollServiceTest.BogusData;
using Voxel.AnonymousPollEntities.Config;
using Microsoft.Extensions.Options;
using Voxel.AnonymousPollBusiness.Mappings;

namespace Voxel.AnonymousPollServiceTest.ServiceTest
{
    public class TestService
    {
        #region Private Definitions

        private readonly IStudentRepository _studentRepository;
        private readonly IMapper _mapper;
        private readonly IParserData<SearchData> _parserData;
        private readonly IParserData<BulkDataRequest> _parserDataDataService;
        private readonly Mock<IOptions<ParserConfig>> _parserConfigOption;
        private readonly IServiceProvider _services;
        private readonly VoxelDBContext _dbContext;

        #endregion

        #region Constructor

        public TestService()
        {
            _services = ConfigureServices();
            _dbContext = _services.GetRequiredService<VoxelDBContext>();
            _mapper = MappingProfile.GetMapper();

            _studentRepository = _services.GetRequiredService<IStudentRepository>();

            _parserConfigOption = new Mock<IOptions<ParserConfig>>();
            _parserConfigOption.Setup(s => s.Value).Returns(new ParserConfig()
            {
                Delimiter =",",
                HasHeaderRecord = false,
                NewLine = "\r\n"
            });

            _parserData = new ParserData<SearchData>(_parserConfigOption.Object);
            _parserDataDataService = new ParserData<BulkDataRequest>(_parserConfigOption.Object);


        }

        #endregion

        #region Private Methods

        private async Task<DataService> CreateDataServiceAsync()
        {
            await _dbContext.Database.EnsureCreatedAsync();

            return new DataService(_studentRepository,
                                    _mapper,
                                    _parserDataDataService);
        }

        private async Task<PollService> CreatePollServiceAsync()
        {
            await _dbContext.Database.EnsureCreatedAsync();

            return new PollService(_studentRepository,
                                    _mapper,
                                    _parserData);
        }

        private IServiceProvider ConfigureServices()
        {
            IServiceCollection serviceCollection = new ServiceCollection();

            SqliteConnection _connection = new SqliteConnection("DataSource=:memory:");
            _connection.Open();

            serviceCollection.AddSingleton(_connection);
            serviceCollection.AddDbContext<VoxelDBContext>(cfg => cfg.UseSqlite(_connection));

            serviceCollection.AddScoped<IStudentRepository, StudentRepository>();

            return serviceCollection.BuildServiceProvider();
        }

        #endregion


        #region Tests

        [Fact]
        public async void DataServiceTest()
        {
            var service = await CreateDataServiceAsync();

            var file = TestBogusData.GetFile();

            // Act
            var result = await service.BulkDataAsync(file);

            // Assert
            Assert.IsType<BulkDataResponse>(result);

            var students = await _dbContext.Students.ToListAsync();

            // Assert
            Assert.Equal(10, students.Count());

            // Assert
            Assert.Equal("10 records were inserted in DB", result.Result[0]);
        }

        [Fact]
        public async void PollServiceTest()
        {
            var dataService = await CreateDataServiceAsync();

            var file = TestBogusData.GetFile();

            // Act
            var result = await dataService.BulkDataAsync(file);

            var service = await CreatePollServiceAsync();

            var request = TestBogusData.GetSearchDatRequest();

            // Act
            var resultExecute = await service.ExecuteAsync(request);

            // Assert
            Assert.IsType<SearchDataResponse>(resultExecute);

            // Assert
            Assert.Equal(2, resultExecute.Result.Count());

            // Assert
            Assert.Equal("Case #1: Jennifer Martin Bell,Morgan Edwards Morales", resultExecute.Result[0]);

            // Assert
            Assert.Equal("Case #2: NONE", resultExecute.Result[1]);
        }

        #endregion
    }
}
