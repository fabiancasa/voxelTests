﻿using Microsoft.AspNetCore.Http;
using System.Text;
using Microsoft.AspNetCore.Http.Internal;
using System.IO;
using Voxel.AnonymousPollEntities.DTOs;
using System.Collections.Generic;

namespace Voxel.AnonymousPollServiceTest.BogusData
{
    public static class TestBogusData
    {
        public static IFormFile GetFile()
        {
            var data = File.OpenRead(Path.Combine("..", "..", "..", "SeedData", "student.txt"));

            IFormFile file = new FormFile(data, 0, data.Length, data.Name, "student.txt");

            return file;
        }


        public static SearchDataRequest GetSearchDatRequest()
        {
            return new SearchDataRequest()
            {
                TCases = 2,
                Cases = new List<string>()
                {
                    "F,18,Computer Science,2",
                    "F,18,Software Engineer,2"
                }
            };
        }
    }
}
